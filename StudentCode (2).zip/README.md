## Project Name:  Income Tax Calculator Application

### Course Title:
LIS 2360:  Web Application Development

### Assignment Date:  
(Month Day, Year)

### Student Name:  
(First and Last Name)

### Project Description:
(In your own words, briefly describe the assignment.)

### View Project:
(Replace this statement with your Github Page URL that was created when you 
 published the project.)

### Lessons Learned in the Assignment:
1. (Briefly describe a lesson/concept learned in this lesson.)
2. (Briefly describe a lesson/concept learned in this lesson.)
3. (Briefly describe a lesson/concept learned in this lesson.)
